# GlossPin / 词钉 — 技术设计文档

## 1. 整体架构

```
┌─────────────────────────────────────────────────┐
│                  Browser Extension               │
│                                                  │
│  ┌──────────┐  ┌──────────┐  ┌───────────────┐  │
│  │ Content   │  │ Background│  │ Popup / Options│  │
│  │ Script    │  │ Service   │  │ Pages          │  │
│  │           │  │ Worker    │  │                │  │
│  │ - 划词监听 │  │ - 翻译调度 │  │ - 生词本管理   │  │
│  │ - 行内标注 │  │ - 存储管理 │  │ - 设置面板     │  │
│  │ - 标注恢复 │  │ - 快捷键   │  │ - 站点开关     │  │
│  │ - 悬停tooltip│ │ - 引擎管理│  │ - 翻译源管理   │  │
│  └─────┬─────┘  └─────┬─────┘  └───────┬───────┘  │
│        │              │                │          │
│        └──── chrome.runtime.message ───┘          │
│                       │                           │
│              ┌────────┴────────┐                   │
│              │  Storage Layer  │                   │
│              │ chrome.storage  │                   │
│              │   .local        │                   │
│              └────────┬────────┘                   │
└───────────────────────┼─────────────────────────────┘
                        │
          ┌─────────────┼─────────────┐
          │             │             │
     ┌────┴────┐  ┌────┴────┐  ┌────┴────┐
     │ 百度翻译 │  │ 有道翻译 │  │ Google  │
     │  API    │  │  API    │  │Translate│
     └─────────┘  └─────────┘  └─────────┘
                        │
                  ┌─────┴─────┐
                  │ 大模型 API │
                  │ (可选)     │
                  └───────────┘
```

## 2. 技术选型

| 类别 | 选型 | 理由 |
|------|------|------|
| 语言 | TypeScript | 类型安全，重构友好 |
| 构建 | Vite + CRXJS | 热更新，Manifest V3 原生支持 |
| 跨浏览器 | webextension-polyfill | 抹平 Chrome/Firefox API 差异 |
| UI 框架 | 无框架（原生 DOM） | Content Script 轻量，避免样式污染 |
| Popup/Options | Preact | 极小体积（3KB），JSX 开发体验 |
| 样式 | CSS Modules | Content Script 样式隔离 |
| 存储 | chrome.storage.local | 扩展原生，跨标签页同步 |
| 测试 | Vitest | 与 Vite 生态一致 |
| 包管理 | pnpm | 快速，磁盘占用小 |

## 3. 目录结构

```
glosspin/
├── src/
│   ├── content/              # Content Script（注入网页）
│   │   ├── index.ts          # 入口：划词监听、标注恢复
│   │   ├── selection.ts      # 划词检测与文本提取
│   │   ├── annotator.ts      # 行内标注渲染（插入/删除/样式）
│   │   ├── tooltip.ts        # 悬停详细释义 tooltip
│   │   └── styles.module.css # 标注样式（CSS Modules 隔离）
│   │
│   ├── background/           # Service Worker
│   │   ├── index.ts          # 入口：消息路由
│   │   ├── translator.ts     # 翻译调度器（引擎选择、fallback）
│   │   ├── engines/          # 翻译引擎适配器
│   │   │   ├── types.ts      # 引擎接口定义
│   │   │   ├── baidu.ts      # 百度翻译
│   │   │   ├── youdao.ts     # 有道翻译
│   │   │   ├── google.ts     # Google Translate
│   │   │   └── llm.ts        # 大模型翻译（通用 OpenAI 格式）
│   │   └── storage.ts        # 存储管理（标注 + 生词本 + 设置）
│   │
│   ├── popup/                # Popup 弹窗
│   │   ├── index.html
│   │   ├── index.tsx         # Preact 入口
│   │   ├── Wordbook.tsx      # 生词本列表
│   │   ├── SiteToggle.tsx    # 当前站点开关
│   │   └── QuickActions.tsx  # 快捷操作（清除标注等）
│   │
│   ├── options/              # 设置页面
│   │   ├── index.html
│   │   ├── index.tsx
│   │   ├── EngineSettings.tsx    # 翻译源管理
│   │   ├── StyleSettings.tsx     # 标注样式设置
│   │   ├── ShortcutSettings.tsx  # 快捷键设置
│   │   └── SiteRules.tsx         # 站点白名单/黑名单
│   │
│   └── shared/               # 共享模块
│       ├── messages.ts       # 消息类型定义
│       ├── storage-keys.ts   # 存储 key 常量
│       └── types.ts          # 公共类型
│
├── public/
│   ├── manifest.json         # 扩展清单（Manifest V3）
│   └── icons/                # 扩展图标
│
├── tests/                    # 测试
├── package.json
├── tsconfig.json
├── vite.config.ts
└── CLAUDE.md                 # 项目约束文档
```

## 4. 数据结构

### 4.1 标注数据（按 URL 存储）

```typescript
interface Annotation {
  id: string;              // 唯一 ID（nanoid）
  originalText: string;    // 原文
  translation: string;     // 译文
  partOfSpeech?: string;   // 词性（如 n. adj. v.）
  engine: string;          // 翻译引擎标识
  // 定位信息（用于页面恢复标注）
  xpath: string;           // 原文所在 DOM 节点的 XPath
  textOffset: number;      // 在文本节点中的偏移量
  textLength: number;      // 选中文本长度
  // 元数据
  createdAt: number;       // 时间戳
  pinned: boolean;         // 是否已收藏到生词本
}

// 存储结构：annotations:{url} → Annotation[]
```

### 4.2 生词本

```typescript
interface WordEntry {
  id: string;
  word: string;            // 原文
  translation: string;     // 译文
  context: string;         // 来源句子
  sourceUrl: string;       // 来源页面 URL
  sourceTitle: string;     // 来源页面标题
  engine: string;          // 翻译引擎
  createdAt: number;
  tags: string[];          // 用户标签（预留）
}
```

### 4.3 设置

```typescript
interface Settings {
  // 翻译
  targetLang: string;              // 目标语言，默认 'zh-CN'
  enginePriority: string[];        // 引擎优先级，如 ['baidu', 'youdao', 'google']
  engineConfigs: Record<string, {  // 各引擎配置
    enabled: boolean;
    apiKey?: string;
    endpoint?: string;
  }>;
  // 标注样式
  annotationStyle: {
    color: string;                 // 标注颜色
    fontSize: 'small' | 'medium' | 'large';
    format: 'bracket' | 'subscript' | 'superscript';
  };
  // 行为
  triggerMode: 'auto' | 'shortcut'; // 自动划词 or 快捷键触发
  phraseMode: 'whole' | 'word-by-word'; // 多词短语：整句翻译 / 逐词翻译
  shortcuts: Record<string, string>;
  // 站点规则
  siteMode: 'blacklist' | 'whitelist';
  siteList: string[];              // 域名列表
  // 跳过翻译的语言
  skipLangs: string[];             // 如 ['zh-CN']，目标语言默认跳过
}
```

## 5. 消息通信协议

Content Script ↔ Background Service Worker 通过 `chrome.runtime.sendMessage` 通信：

```typescript
// 翻译请求
type TranslateRequest = {
  type: 'TRANSLATE';
  text: string;
  targetLang: string;
  engine?: string;  // 指定引擎，不传则按优先级
};

type TranslateResponse = {
  translation: string;
  engine: string;
  partOfSpeech?: string;  // 词性（n. adj. v. 等）
  phonetic?: string;    // 音标
  definitions?: string[]; // 详细释义
  examples?: string[];    // 例句
};

// 标注持久化
type SaveAnnotations = {
  type: 'SAVE_ANNOTATIONS';
  url: string;
  annotations: Annotation[];
};

type LoadAnnotations = {
  type: 'LOAD_ANNOTATIONS';
  url: string;
};

// 生词本
type PinWord = {
  type: 'PIN_WORD';
  entry: WordEntry;
};

// 设置
type GetSettings = { type: 'GET_SETTINGS' };
type UpdateSettings = { type: 'UPDATE_SETTINGS'; settings: Partial<Settings> };
```

## 6. 关键流程

### 6.1 划词翻译流程

```
用户选中文本
  → selection.ts 检测 mouseup 事件
  → 提取选中文本 + 记录 DOM 位置（XPath + offset）
  → 发送 TRANSLATE 消息到 Background
  → translator.ts 按优先级调用翻译引擎
  → 返回翻译结果
  → annotator.ts 在选中文本后方插入行内标注 <span>
  → 发送 SAVE_ANNOTATIONS 持久化
```

### 6.2 标注恢复流程

```
页面加载完成（DOMContentLoaded）
  → content/index.ts 发送 LOAD_ANNOTATIONS
  → 获取当前 URL 对应的标注数据
  → 遍历标注，通过 XPath + offset 定位原始 DOM 节点
  → annotator.ts 重新插入标注 <span>
  → 定位失败的标注静默跳过（页面结构可能已变）
```

### 6.3 翻译引擎 Fallback

```
translator.ts 收到翻译请求
  → 按 enginePriority 顺序尝试
  → 引擎 A 调用 → 超时/报错 → 引擎 B → 超时/报错 → 引擎 C
  → 全部失败 → 返回错误提示
  → 单次超时阈值：3 秒
```

## 7. 样式隔离策略

Content Script 注入的标注样式必须与宿主页面隔离：

- 标注 `<span>` 使用 CSS Modules 生成唯一类名，避免命名冲突
- 所有标注样式使用 `!important` 防止被宿主页面覆盖
- tooltip 使用 Shadow DOM 渲染，完全隔离样式
- 标注元素添加 `data-glosspin` 属性，便于识别和批量操作

## 8. 安全考虑

- API Key 使用 `chrome.storage.local` 存储（扩展沙箱内，其他扩展无法访问）
- 翻译请求通过 Background Service Worker 发出（避免 Content Script 的 CSP 限制）
- 不执行任何从翻译结果中获取的 HTML/JS（纯文本插入，防 XSS）
- 大模型 API 请求不发送页面完整内容，仅发送选中文本
