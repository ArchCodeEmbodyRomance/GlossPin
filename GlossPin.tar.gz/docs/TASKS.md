# GlossPin MVP 任务拆解

## Phase 1 — 项目骨架

### Task 1.1 初始化项目
- pnpm init
- 安装依赖：vite, @crxjs/vite-plugin, typescript, preact, webextension-polyfill, nanoid
- 配置 tsconfig.json, vite.config.ts
- 创建 manifest.json（Manifest V3）
- 验证：`pnpm build` 能成功构建空扩展

### Task 1.2 搭建目录结构
- 创建 src/content/, src/background/, src/popup/, src/options/, src/shared/
- 各目录放入空的入口文件
- 验证：目录结构与 DESIGN.md 一致

---

## Phase 2 — 核心翻译链路

### Task 2.1 共享类型定义
- src/shared/types.ts — Annotation, WordEntry, Settings 接口
- src/shared/messages.ts — 消息类型定义（TranslateRequest, TranslateResponse 等）
- src/shared/storage-keys.ts — 存储 key 常量

### Task 2.2 翻译引擎接口 + Google 引擎
- src/background/engines/types.ts — TranslateEngine 接口定义
- src/background/engines/google.ts — Google Translate 免费接口实现

### Task 2.3 翻译调度器
- src/background/translator.ts — 按优先级调用引擎，支持 fallback，超时 3 秒

### Task 2.4 Background 消息路由
- src/background/index.ts — 监听 chrome.runtime.onMessage，路由到 translator/storage

---

## Phase 3 — 划词 + 行内标注

### Task 3.1 划词检测
- src/content/selection.ts — mouseup 事件监听，提取选中文本，记录 XPath + offset

### Task 3.2 行内标注渲染
- src/content/annotator.ts — 在选中文本后插入标注 `<span>`，支持删除（× 按钮）
- src/content/styles.module.css — 标注默认样式（小字号、半透明背景、data-glosspin 属性）

### Task 3.3 Content Script 入口
- src/content/index.ts — 串联：划词 → 翻译请求 → 插入标注

---

## Phase 4 — 标注持久化

### Task 4.1 存储层封装
- src/background/storage.ts — chrome.storage.local 读写封装（标注 CRUD、设置读写）

### Task 4.2 标注持久化 + 恢复
- 划词标注后自动保存到 storage（按 URL 存储）
- 页面加载时通过 XPath + offset 恢复标注
- 删除标注时同步更新 storage

---

## Phase 5 — 基础 UI

### Task 5.1 Popup 页面
- src/popup/index.html + index.tsx
- 功能：扩展开关、清除当前页标注按钮
- 简洁样式

### Task 5.2 扩展图标
- public/icons/ — 16x16, 48x48, 128x128 图标

---

## Phase 6 — 测试 & 打包

### Task 6.1 单元测试
- translator 调度逻辑测试
- storage 读写测试
- annotator DOM 操作测试

### Task 6.2 集成验证
- Chrome 加载未打包扩展
- 端到端手动测试：划词 → 标注 → 累积 → 刷新恢复 → 删除
- `pnpm build` 产物检查

---

## 后续迭代任务

### Options 设置页面
- 跳过翻译的语言选择（skipLangs 配置，如中文、日语等不翻译）
- 翻译源管理（引擎优先级、API Key 配置）
- 标注样式自定义（颜色、字号、格式）
- 快捷键自定义
- 站点白名单/黑名单管理

### 悬停语音朗读
- 鼠标悬停在标注上一段时间（如 1 秒）后，自动朗读原文单词/短语
- 使用浏览器内置 Web Speech API（SpeechSynthesis），无需外部服务
- 语音语言自动匹配原文语言
- 可在设置中开关此功能、调整悬停延迟时间

### 逐词批量翻译优化
- 翻译引擎接口增加 `translateBatch` 方法
- Google / 百度：用换行符 `\n` 拼接多词，一次请求按行返回，支持逐词词性
- 有道：用空格拼接为整句一次请求，返回整句译文，不显示词性等详细信息
- Content Script 逐词模式调用 `translateBatch` 替代循环单次请求

### 翻译引擎 JSON 配置化
- 每个引擎的参数、行为差异统一用 JSON 配置描述，支持用户修改
- 配置结构示例：

```json
{
  "google": {
    "name": "Google 翻译",
    "endpoint": "https://translate.googleapis.com/translate_a/single",
    "apiKey": "",
    "batchMode": "newline",
    "batchSeparator": "\n",
    "supportsPartOfSpeech": true,
    "supportsPhonetic": true,
    "timeout": 3000,
    "params": {
      "client": "gtx",
      "dj": "1",
      "dt": ["t", "bd"]
    }
  },
  "baidu": {
    "name": "百度翻译",
    "endpoint": "https://fanyi-api.baidu.com/api/trans/vip/translate",
    "apiKey": "",
    "secretKey": "",
    "batchMode": "newline",
    "batchSeparator": "\n",
    "supportsPartOfSpeech": true,
    "supportsPhonetic": false,
    "timeout": 3000,
    "params": {}
  },
  "youdao": {
    "name": "有道翻译",
    "endpoint": "https://openapi.youdao.com/api",
    "apiKey": "",
    "appSecret": "",
    "batchMode": "space",
    "batchSeparator": " ",
    "supportsPartOfSpeech": false,
    "supportsPhonetic": true,
    "timeout": 3000,
    "params": {}
  },
  "llm": {
    "name": "大模型翻译",
    "endpoint": "",
    "apiKey": "",
    "batchMode": "newline",
    "batchSeparator": "\n",
    "supportsPartOfSpeech": true,
    "supportsPhonetic": false,
    "timeout": 10000,
    "model": "",
    "params": {}
  }
}
```

- 字段说明：
  - `batchMode`: 批量翻译方式（`newline` 换行拼接 / `space` 空格拼接 / `single` 不支持批量）
  - `batchSeparator`: 拼接分隔符
  - `supportsPartOfSpeech`: 是否支持返回词性
  - `supportsPhonetic`: 是否支持返回音标
  - `timeout`: 单次请求超时（ms）
  - `params`: 引擎特有的请求参数
- 配置存储在 `chrome.storage.local`，Options 页面可编辑
- 新增引擎只需添加 JSON 配置 + 对应的请求/解析适配器

### 存储策略优化
- 去掉 30 天过期清理逻辑，只通过数量和内存大小控制存储上限
- 浏览器所有窗口关闭后自动清空所有标注存储（监听 `chrome.runtime.onSuspend` 或 `chrome.windows.onRemoved`）
