# GlossPin 开发环境搭建

## 前置条件

- Node.js >= 18
- pnpm（`npm install -g pnpm`）

## 一键恢复

```bash
cd D:\Test\GlossPin
pnpm install
pnpm build
```

## 加载扩展到浏览器

- Edge: `edge://extensions` → 开发人员模式 → 加载解压缩 → 选择 `dist/` 目录
- Chrome: `chrome://extensions` → 开发者模式 → 加载已解压的扩展程序 → 选择 `dist/` 目录

## 开发命令

```bash
pnpm dev       # 开发模式（热更新）
pnpm build     # 生产构建
pnpm test      # 运行测试
pnpm lint      # 类型检查
```

## 注意事项

- 修改代码后需 `pnpm build`，然后在浏览器扩展页面点刷新按钮，再刷新网页
- pnpm 使用全局 store 硬链接，node_modules 不会重复占用磁盘
- node_modules 和 dist 已在 .gitignore 中，不会提交
