# GlossPin / 词钉

跨浏览器划词行内标注翻译扩展。翻译结果"钉"在原文旁边，支持累积标注和持久化。

## 技术栈

- 语言：TypeScript（严格模式）
- 构建：Vite + CRXJS
- 包管理：pnpm
- Content Script UI：原生 DOM（不引入框架）
- Popup / Options UI：Preact
- 样式隔离：CSS Modules（Content Script）
- 跨浏览器：webextension-polyfill
- 测试：Vitest
- 扩展规范：Manifest V3

## 目录结构

```
src/
├── content/        # Content Script（注入网页）
├── background/     # Service Worker
│   └── engines/    # 翻译引擎适配器
├── popup/          # 弹窗页面（Preact）
├── options/        # 设置页面（Preact）
└── shared/         # 共享类型和工具
```

## 代码规范

- 注释和文档使用中文
- 变量/函数命名：camelCase
- 类型/接口命名：PascalCase
- 常量命名：UPPER_SNAKE_CASE
- 文件命名：kebab-case.ts（组件文件 PascalCase.tsx）
- 每个文件职责单一，不超过 300 行
- 导出类型使用 `export type`
- 禁止 `any`，必要时用 `unknown`

## Git 提交规范

格式：`<type>(<scope>): <description>`

type 取值：
- feat: 新功能
- fix: 修复
- refactor: 重构
- style: 样式
- docs: 文档
- test: 测试
- chore: 构建/工具

scope 取值：content / background / popup / options / shared / engine

示例：`feat(content): 实现划词检测和文本提取`

## 常用命令

```bash
pnpm dev          # 开发模式（热更新）
pnpm build        # 生产构建
pnpm test         # 运行测试
pnpm lint         # 代码检查
```

## 关键约束

1. Content Script 注入的 DOM 必须使用 CSS Modules 隔离样式，避免污染宿主页面
2. 翻译结果以纯文本插入，禁止 innerHTML，防止 XSS
3. 所有网络请求通过 Background Service Worker 发出（CSP 限制）
4. API Key 存储在 chrome.storage.local（扩展沙箱内）
5. 标注元素统一添加 `data-glosspin` 属性
6. 翻译引擎实现统一接口（`TranslateEngine`），通过适配器模式接入
7. 不收集用户浏览数据，仅在用户触发翻译时发送网络请求

## 参考文档

- PRD：`docs/PRD.md`
- 技术设计：`docs/DESIGN.md`
- 任务拆解：`docs/TASKS.md`（含后续迭代任务）

## 当前开发状态

MVP 已完成，已实现功能：
- 划词翻译 + 行内标注（带词性）
- 单词自动补全
- 多词整句/逐词模式切换
- 目标语言跳过
- 划词后页面所有同词位置都标注
- 标注持久化 + 刷新恢复
- Popup（开关、多词模式、存储统计、清除当前页、清空所有）

待开发（见 docs/TASKS.md 后续迭代任务）：
- Options 设置页面（skipLangs、翻译源管理、样式自定义、快捷键、站点规则）
- 悬停语音朗读
- 逐词批量翻译优化
- 翻译引擎 JSON 配置化
- 存储策略优化（去掉时间过期，只按数量/内存控制，浏览器关闭后清空）

## 工作流偏好

- 修改需求时：先改代码 → 问用户还有没有别的要改 → 确认没有了再打包（pnpm build）+ 更新文档
- 每步和用户沟通确认后再往下走
- 聊天和代码注释使用中文

## 已知问题

- CRXJS 2.4.0 与 Vite 8/6 不兼容，当前使用 CRXJS 2.0.0-beta.33 + Vite 5
- @preact/preset-vite 用 2.8.2 配合 Vite 5
- vitest 用 1.x 配合 Vite 5
- 更新扩展后浏览器需手动刷新扩展 + 刷新页面
