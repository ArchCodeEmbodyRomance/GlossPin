# GlossPin / 词钉

划词行内标注翻译浏览器扩展。翻译结果直接"钉"在原文旁边，支持累积标注、刷新恢复、持久化存储。

## 功能

- 划词即翻译，行内标注紧跟原文
- 单词显示词性（n. adj. v. 等）
- 划词不完整自动补全到完整单词
- 多词短语支持整句/逐词两种模式
- 标注按页面持久化，刷新自动恢复
- 目标语言自动跳过不翻译
- 存储自动清理（30 天过期 / 200 页上限）

## 安装

```bash
pnpm install
pnpm build
```

在浏览器中加载 `dist/` 目录：
- Chrome: `chrome://extensions` → 开发者模式 → 加载已解压的扩展程序
- Edge: `edge://extensions` → 开发人员模式 → 加载解压缩
- Firefox: `about:debugging` → 此 Firefox → 临时加载附加组件

## 开发

```bash
pnpm dev       # 开发模式（热更新）
pnpm build     # 生产构建
pnpm test      # 运行测试
pnpm lint      # 类型检查
```

## 技术栈

- TypeScript + Vite + CRXJS
- Preact（Popup UI）
- Manifest V3 / WebExtension API
- Google Translate API

## 目录结构

```
src/
├── content/        # Content Script（划词、标注、样式）
├── background/     # Service Worker（翻译调度、存储、消息路由）
│   └── engines/    # 翻译引擎适配器
├── popup/          # 弹窗页面
└── shared/         # 共享类型和工具
```

## 文档

- [产品需求文档](docs/PRD.md)
- [技术设计文档](docs/DESIGN.md)
- [任务拆解](docs/TASKS.md)

## License

ISC
