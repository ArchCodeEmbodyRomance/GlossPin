import { render } from 'preact';
import { useState, useEffect } from 'preact/hooks';
import { ENABLED_KEY } from '@/shared/storage-keys';
import type { MessageResponse } from '@/shared/messages';
import type { Settings } from '@/shared/types';

interface StorageStats {
  pageCount: number;
  totalAnnotations: number;
  bytesUsed: number;
}

function App() {
  const [enabled, setEnabled] = useState(true);
  const [phraseMode, setPhraseMode] = useState<'whole' | 'word-by-word'>('whole');
  const [status, setStatus] = useState('');
  const [stats, setStats] = useState<StorageStats | null>(null);

  const loadStats = async () => {
    const res: MessageResponse = await chrome.runtime.sendMessage({ type: 'GET_STORAGE_STATS' });
    if (res.success && res.data) setStats(res.data as StorageStats);
  };

  useEffect(() => {
    chrome.storage.local.get(ENABLED_KEY).then((result) => {
      setEnabled(result[ENABLED_KEY] ?? true);
    });
    chrome.runtime.sendMessage({ type: 'GET_SETTINGS' }).then((res: MessageResponse) => {
      if (res.success && res.data) {
        setPhraseMode((res.data as Settings).phraseMode);
      }
    });
    loadStats();
  }, []);

  const showStatus = (msg: string) => {
    setStatus(msg);
    setTimeout(() => setStatus(''), 1500);
  };

  const toggleEnabled = async () => {
    const next = !enabled;
    setEnabled(next);
    await chrome.storage.local.set({ [ENABLED_KEY]: next });
    showStatus(next ? '已启用' : '已禁用');
  };

  const togglePhraseMode = async () => {
    const next = phraseMode === 'whole' ? 'word-by-word' : 'whole';
    setPhraseMode(next);
    await chrome.runtime.sendMessage({ type: 'UPDATE_SETTINGS', settings: { phraseMode: next } });
  };

  const clearCurrentPage = async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url) return;
    await chrome.runtime.sendMessage({ type: 'CLEAR_ANNOTATIONS', url: tab.url });
    if (tab.id) {
      await chrome.tabs.sendMessage(tab.id, { type: 'CLEAR_PAGE_ANNOTATIONS' });
    }
    showStatus('已清除当前页标注');
    loadStats();
  };

  const clearAll = async () => {
    await chrome.runtime.sendMessage({ type: 'CLEAR_ALL_ANNOTATIONS' });
    showStatus('已清空所有标注');
    loadStats();
  };

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  };

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <span style={styles.logo}>📌</span>
        <span style={styles.title}>GlossPin</span>
        <span style={styles.subtitle}>词钉</span>
      </div>

      <div style={styles.row}>
        <span>划词翻译</span>
        <button
          style={{
            ...styles.toggleBtn,
            background: enabled ? '#059669' : '#9ca3af',
          }}
          onClick={toggleEnabled}
        >
          {enabled ? 'ON' : 'OFF'}
        </button>
      </div>

      <div style={styles.row}>
        <span>多词模式</span>
        <button
          style={{
            ...styles.toggleBtn,
            background: phraseMode === 'whole' ? '#3b82f6' : '#059669',
          }}
          onClick={togglePhraseMode}
        >
          {phraseMode === 'whole' ? '整句' : '逐词'}
        </button>
      </div>

      {stats && (
        <div style={styles.stats}>
          <span>{stats.pageCount} 个页面</span>
          <span style={styles.dot}>·</span>
          <span>{stats.totalAnnotations} 条标注</span>
          <span style={styles.dot}>·</span>
          <span>{formatBytes(stats.bytesUsed)}</span>
        </div>
      )}

      <button style={styles.btn} onClick={clearCurrentPage}>
        清除当前页标注
      </button>

      <button style={{ ...styles.btn, color: '#dc2626', borderColor: '#fecaca' }} onClick={clearAll}>
        清空所有标注
      </button>

      {status && <div style={styles.status}>{status}</div>}
    </div>
  );
}

const styles: Record<string, Record<string, string | number>> = {
  container: {
    width: 260,
    padding: 16,
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    fontSize: 14,
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    gap: 6,
    marginBottom: 16,
    paddingBottom: 12,
    borderBottom: '1px solid #e5e7eb',
  },
  logo: { fontSize: 20 },
  title: { fontSize: 16, fontWeight: 600 },
  subtitle: { fontSize: 12, color: '#9ca3af' },
  row: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  toggleBtn: {
    border: 'none',
    color: '#fff',
    borderRadius: 4,
    padding: '4px 12px',
    cursor: 'pointer',
    fontSize: 12,
    fontWeight: 600,
  },
  segToggle: {
    display: 'flex',
    borderRadius: 4,
    overflow: 'hidden',
    cursor: 'pointer',
    border: '1px solid #e5e7eb',
  },
  segOption: {
    padding: '3px 10px',
    fontSize: 12,
    fontWeight: 500,
    color: '#9ca3af',
    background: '#fff',
    transition: 'all 0.15s',
  },
  segActive: {
    color: '#fff',
    background: '#059669',
  },
  segActiveAlt: {
    color: '#fff',
    background: '#059669',
  },
  stats: {
    display: 'flex',
    justifyContent: 'center',
    gap: 4,
    fontSize: 11,
    color: '#9ca3af',
    marginBottom: 12,
  },
  dot: { color: '#d1d5db' },
  btn: {
    width: '100%',
    padding: '8px 0',
    border: '1px solid #e5e7eb',
    borderRadius: 6,
    background: '#fff',
    cursor: 'pointer',
    fontSize: 13,
    color: '#374151',
    marginBottom: 8,
  },
  status: {
    marginTop: 4,
    fontSize: 12,
    color: '#059669',
    textAlign: 'center',
  },
};

render(<App />, document.getElementById('app')!);
