import type { Annotation, Settings, WordEntry } from '@/shared/types';
import { annotationsKey, ANNOTATIONS_PREFIX, WORDBOOK_KEY, SETTINGS_KEY } from '@/shared/storage-keys';

// 存储治理常量
const MAX_EXPIRE_DAYS = 30;       // 标注过期天数
const MAX_PAGE_COUNT = 200;       // 最多保留多少个页面的标注

// 标注数据
export async function saveAnnotations(url: string, annotations: Annotation[]): Promise<void> {
  await chrome.storage.local.set({ [annotationsKey(url)]: annotations });
}

export async function loadAnnotations(url: string): Promise<Annotation[]> {
  const key = annotationsKey(url);
  const result = await chrome.storage.local.get(key);
  return result[key] ?? [];
}

export async function clearAnnotations(url: string): Promise<void> {
  await chrome.storage.local.remove(annotationsKey(url));
}

// 清空所有标注数据
export async function clearAllAnnotationsStorage(): Promise<void> {
  const all = await chrome.storage.local.get(null);
  const keys = Object.keys(all).filter((k) => k.startsWith(ANNOTATIONS_PREFIX));
  if (keys.length > 0) {
    await chrome.storage.local.remove(keys);
  }
}

// 获取存储统计信息
export async function getStorageStats(): Promise<{ pageCount: number; totalAnnotations: number; bytesUsed: number }> {
  const all = await chrome.storage.local.get(null);
  let pageCount = 0;
  let totalAnnotations = 0;

  for (const [key, value] of Object.entries(all)) {
    if (key.startsWith(ANNOTATIONS_PREFIX)) {
      pageCount++;
      totalAnnotations += (value as Annotation[]).length;
    }
  }

  const bytesUsed = await new Promise<number>((resolve) => {
    chrome.storage.local.getBytesInUse(null, resolve);
  });

  return { pageCount, totalAnnotations, bytesUsed };
}

// 自动清理：过期标注 + 超出上限
export async function cleanupAnnotations(): Promise<void> {
  const all = await chrome.storage.local.get(null);
  const now = Date.now();
  const expireMs = MAX_EXPIRE_DAYS * 24 * 60 * 60 * 1000;
  const keysToRemove: string[] = [];

  // 收集所有标注页面及其最新时间
  const pages: { key: string; latestTime: number }[] = [];

  for (const [key, value] of Object.entries(all)) {
    if (!key.startsWith(ANNOTATIONS_PREFIX)) continue;
    const annotations = value as Annotation[];
    if (annotations.length === 0) {
      keysToRemove.push(key);
      continue;
    }

    const latestTime = Math.max(...annotations.map((a) => a.createdAt));

    // 过期清理
    if (now - latestTime > expireMs) {
      keysToRemove.push(key);
    } else {
      pages.push({ key, latestTime });
    }
  }

  // 超出上限：按时间排序，删除最旧的
  if (pages.length > MAX_PAGE_COUNT) {
    pages.sort((a, b) => b.latestTime - a.latestTime);
    const overflow = pages.slice(MAX_PAGE_COUNT);
    for (const p of overflow) {
      keysToRemove.push(p.key);
    }
  }

  if (keysToRemove.length > 0) {
    await chrome.storage.local.remove(keysToRemove);
  }
}

// 生词本
export async function pinWord(entry: WordEntry): Promise<void> {
  const wordbook = await getWordbook();
  wordbook.push(entry);
  await chrome.storage.local.set({ [WORDBOOK_KEY]: wordbook });
}

export async function getWordbook(): Promise<WordEntry[]> {
  const result = await chrome.storage.local.get(WORDBOOK_KEY);
  return result[WORDBOOK_KEY] ?? [];
}

// 设置
export async function getSettings(): Promise<Settings> {
  const result = await chrome.storage.local.get(SETTINGS_KEY);
  return result[SETTINGS_KEY] ?? DEFAULT_SETTINGS;
}

export async function updateSettings(partial: Partial<Settings>): Promise<void> {
  const current = await getSettings();
  const updated = { ...current, ...partial };
  await chrome.storage.local.set({ [SETTINGS_KEY]: updated });
}

const DEFAULT_SETTINGS: Settings = {
  targetLang: 'zh-CN',
  enginePriority: ['google'],
  engineConfigs: {
    google: { enabled: true },
  },
  annotationStyle: {
    color: '#f59e0b',
    fontSize: 'small',
    format: 'bracket',
  },
  triggerMode: 'auto',
  phraseMode: 'whole',
  shortcuts: {
    toggle: 'Ctrl+Shift+G',
    clear: 'Ctrl+Shift+X',
  },
  siteMode: 'blacklist',
  siteList: [],
  skipLangs: ['zh-CN'],
};
