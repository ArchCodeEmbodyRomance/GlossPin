import type { TranslateResult } from '@/shared/types';
import type { TranslateEngine } from './types';

// Google Translate 免费接口
const GOOGLE_TRANSLATE_URL = 'https://translate.googleapis.com/translate_a/single';

export class GoogleEngine implements TranslateEngine {
  readonly name = 'google';

  async translate(text: string, targetLang: string): Promise<TranslateResult> {
    const params = new URLSearchParams({
      client: 'gtx',
      sl: 'auto',
      tl: targetLang,
      dt: 't',   // 翻译
      dj: '1',   // JSON 格式
      q: text,
    });
    // 追加 dt=bd 获取词典/词性信息
    params.append('dt', 'bd');

    const response = await fetch(`${GOOGLE_TRANSLATE_URL}?${params}`);
    if (!response.ok) {
      throw new Error(`Google Translate 请求失败: ${response.status}`);
    }

    const data = await response.json();
    const translation = data.sentences
      ?.map((s: { trans?: string }) => s.trans)
      .filter(Boolean)
      .join('') || '';

    if (!translation) {
      throw new Error('Google Translate 返回空结果');
    }

    // 解析词性（仅单词时有效）
    let partOfSpeech: string | undefined;
    if (data.dict && data.dict.length > 0) {
      const pos = data.dict[0].pos;
      if (pos) {
        partOfSpeech = mapPartOfSpeech(pos);
      }
    }

    return {
      translation,
      engine: this.name,
      partOfSpeech,
    };
  }

  async test(): Promise<boolean> {
    try {
      const result = await this.translate('hello', 'zh-CN');
      return result.translation.length > 0;
    } catch {
      return false;
    }
  }
}

// 将 Google 返回的词性映射为缩写
function mapPartOfSpeech(pos: string): string {
  const map: Record<string, string> = {
    noun: 'n.',
    verb: 'v.',
    adjective: 'adj.',
    adverb: 'adv.',
    pronoun: 'pron.',
    preposition: 'prep.',
    conjunction: 'conj.',
    interjection: 'int.',
    article: 'art.',
    // 中文词性
    '名词': 'n.',
    '动词': 'v.',
    '形容词': 'adj.',
    '副词': 'adv.',
    '代词': 'pron.',
    '介词': 'prep.',
    '连词': 'conj.',
    '感叹词': 'int.',
  };
  return map[pos.toLowerCase()] ?? pos;
}
