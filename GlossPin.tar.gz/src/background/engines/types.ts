import type { TranslateResult } from '@/shared/types';

// 翻译引擎统一接口
export interface TranslateEngine {
  // 引擎标识
  readonly name: string;
  // 执行翻译
  translate(text: string, targetLang: string): Promise<TranslateResult>;
  // 测试连通性
  test(): Promise<boolean>;
}
