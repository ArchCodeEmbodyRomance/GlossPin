import type { TranslateResult } from '@/shared/types';
import type { TranslateEngine } from './engines/types';
import { GoogleEngine } from './engines/google';

// 单次翻译超时阈值
const TIMEOUT_MS = 3000;

// 所有可用引擎
const ALL_ENGINES: Record<string, TranslateEngine> = {
  google: new GoogleEngine(),
};

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`翻译超时 (${ms}ms)`)), ms);
    promise.then(resolve, reject).finally(() => clearTimeout(timer));
  });
}

// 按优先级调用翻译引擎，支持 fallback
export async function translate(
  text: string,
  targetLang: string,
  enginePriority: string[],
  specifiedEngine?: string,
): Promise<TranslateResult> {
  // 指定引擎时直接调用
  if (specifiedEngine && ALL_ENGINES[specifiedEngine]) {
    return withTimeout(
      ALL_ENGINES[specifiedEngine].translate(text, targetLang),
      TIMEOUT_MS,
    );
  }

  // 按优先级 fallback
  const errors: string[] = [];
  for (const name of enginePriority) {
    const engine = ALL_ENGINES[name];
    if (!engine) continue;
    try {
      return await withTimeout(engine.translate(text, targetLang), TIMEOUT_MS);
    } catch (e) {
      errors.push(`${name}: ${(e as Error).message}`);
    }
  }

  throw new Error(`所有翻译引擎均失败:\n${errors.join('\n')}`);
}

// 注册新引擎（供后续扩展百度、有道、大模型等）
export function registerEngine(engine: TranslateEngine): void {
  ALL_ENGINES[engine.name] = engine;
}
