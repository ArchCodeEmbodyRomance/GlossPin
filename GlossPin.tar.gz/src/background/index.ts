import type { Message, MessageResponse } from '@/shared/messages';
import { translate } from './translator';
import {
  loadAnnotations,
  saveAnnotations,
  clearAnnotations,
  clearAllAnnotationsStorage,
  getStorageStats,
  cleanupAnnotations,
  pinWord,
  getSettings,
  updateSettings,
} from './storage';

// 默认引擎优先级
const DEFAULT_PRIORITY = ['google'];

// 扩展启动时自动清理过期标注
cleanupAnnotations();

chrome.runtime.onMessage.addListener(
  (message: Message, _sender, sendResponse: (response: MessageResponse) => void) => {
    handleMessage(message)
      .then(sendResponse)
      .catch((e) => sendResponse({ success: false, error: (e as Error).message }));
    return true; // 异步响应
  },
);

async function handleMessage(message: Message): Promise<MessageResponse> {
  switch (message.type) {
    case 'TRANSLATE': {
      const settings = await getSettings();
      const priority = settings?.enginePriority ?? DEFAULT_PRIORITY;
      const data = await translate(message.text, message.targetLang, priority, message.engine);
      return { success: true, data };
    }
    case 'SAVE_ANNOTATIONS': {
      await saveAnnotations(message.url, message.annotations);
      return { success: true };
    }
    case 'LOAD_ANNOTATIONS': {
      const data = await loadAnnotations(message.url);
      return { success: true, data };
    }
    case 'CLEAR_ANNOTATIONS': {
      await clearAnnotations(message.url);
      return { success: true };
    }
    case 'CLEAR_ALL_ANNOTATIONS': {
      await clearAllAnnotationsStorage();
      return { success: true };
    }
    case 'GET_STORAGE_STATS': {
      const data = await getStorageStats();
      return { success: true, data };
    }
    case 'PIN_WORD': {
      await pinWord(message.entry);
      return { success: true };
    }
    case 'GET_SETTINGS': {
      const data = await getSettings();
      return { success: true, data };
    }
    case 'UPDATE_SETTINGS': {
      await updateSettings(message.settings);
      return { success: true };
    }
    default:
      return { success: false, error: '未知消息类型' };
  }
}
