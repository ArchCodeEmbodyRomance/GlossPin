// 行内标注渲染：在选中文本后插入/删除标注

import type { Annotation } from '@/shared/types';

const GLOSSPIN_ATTR = 'data-glosspin';

// 创建标注 DOM 元素
function createAnnotationElement(annotation: Annotation): HTMLSpanElement {
  const span = document.createElement('span');
  span.setAttribute(GLOSSPIN_ATTR, annotation.id);
  span.className = 'glosspin-annotation';
  const pos = annotation.partOfSpeech ? `${annotation.partOfSpeech} ` : '';
  span.textContent = `[${pos}${annotation.translation}]`;

  // 点击标注本身触发删除（通过 CSS ::after 伪元素显示 ×）
  span.addEventListener('click', (e) => {
    e.stopPropagation();
    // 删除页面上所有同 id 的标注
    document.querySelectorAll(`[${GLOSSPIN_ATTR}="${annotation.id}"]`).forEach((el) => el.remove());
    document.dispatchEvent(
      new CustomEvent('glosspin:remove', { detail: annotation.id }),
    );
  });

  return span;
}

// 查找页面中所有匹配文本的位置（从后往前收集，避免插入后偏移错乱）
function findAllOccurrences(root: Node, text: string): { node: Text; idx: number }[] {
  const matches: { node: Text; idx: number }[] = [];
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  let current: Node | null;

  while ((current = walker.nextNode())) {
    if ((current.parentElement)?.closest('[data-glosspin]')) continue;
    const content = current.textContent || '';
    let from = 0;
    while (true) {
      const idx = content.indexOf(text, from);
      if (idx === -1) break;
      matches.push({ node: current as Text, idx });
      from = idx + 1;
    }
  }

  // 反转，从后往前插入
  return matches.reverse();
}

// 在 Range 末尾插入标注（划词时用，只标注选中的那一处）
export function insertAnnotation(range: Range, annotation: Annotation): boolean {
  try {
    const span = createAnnotationElement(annotation);
    range.collapse(false);
    range.insertNode(span);
    window.getSelection()?.removeAllRanges();
    return true;
  } catch {
    return false;
  }
}

// 标注页面中所有出现的该词（划词时调用）
export function annotateAllOccurrences(annotation: Annotation): number {
  const matches = findAllOccurrences(document.body, annotation.originalText);
  let count = 0;

  for (const { node, idx } of matches) {
    try {
      const range = document.createRange();
      range.setStart(node, idx);
      range.setEnd(node, idx + annotation.originalText.length);
      const span = createAnnotationElement(annotation);
      range.collapse(false);
      range.insertNode(span);
      count++;
    } catch {
      continue;
    }
  }

  window.getSelection()?.removeAllRanges();
  return count;
}

// 恢复标注（页面加载时，标注所有出现的位置）
export function restoreAnnotation(annotation: Annotation): boolean {
  return annotateAllOccurrences(annotation) > 0;
}

// 移除单个标注（移除所有同 id 的）
export function removeAnnotation(id: string): void {
  document.querySelectorAll(`[${GLOSSPIN_ATTR}="${id}"]`).forEach((el) => el.remove());
}

// 清除页面上所有标注
export function clearAllAnnotations(): void {
  document.querySelectorAll(`[${GLOSSPIN_ATTR}]`).forEach((el) => el.remove());
}
