// 划词检测：监听选中事件，提取文本和 DOM 定位信息

export interface SelectionInfo {
  text: string;        // 选中的文本
  xpath: string;       // 文本节点的 XPath
  textOffset: number;  // 在文本节点中的起始偏移
  textLength: number;  // 选中文本长度
  range: Range;        // 原始 Range 对象（用于插入标注）
}

// 获取节点的 XPath
export function getXPath(node: Node): string {
  const parts: string[] = [];
  let current: Node | null = node;

  while (current && current !== document.documentElement) {
    if (current.nodeType === Node.TEXT_NODE) {
      // 文本节点：计算在父元素中是第几个文本节点
      const parent = current.parentNode;
      if (parent) {
        let textIndex = 0;
        for (const child of Array.from(parent.childNodes)) {
          if (child === current) break;
          if (child.nodeType === Node.TEXT_NODE) textIndex++;
        }
        parts.unshift(`text()[${textIndex + 1}]`);
        current = parent;
        continue;
      }
    }

    if (current.nodeType === Node.ELEMENT_NODE) {
      const el = current as Element;
      const tag = el.tagName.toLowerCase();
      const parent = el.parentNode;
      if (parent) {
        const siblings = Array.from(parent.children).filter(
          (c) => c.tagName.toLowerCase() === tag,
        );
        const index = siblings.indexOf(el) + 1;
        parts.unshift(siblings.length > 1 ? `${tag}[${index}]` : tag);
      } else {
        parts.unshift(tag);
      }
    }

    current = current.parentNode;
  }

  return '/' + parts.join('/');
}

// 通过 XPath 定位节点
export function resolveXPath(xpath: string): Node | null {
  try {
    const result = document.evaluate(
      xpath,
      document.documentElement,
      null,
      XPathResult.FIRST_ORDERED_NODE_TYPE,
      null,
    );
    return result.singleNodeValue;
  } catch {
    return null;
  }
}

// 判断字符是否为单词字符
function isWordChar(ch: string): boolean {
  return /[a-zA-Z\u00C0-\u024F'-]/.test(ch);
}

// 将选区扩展到完整单词边界
function expandToWord(textContent: string, offset: number, length: number): { offset: number; length: number } {
  let start = offset;
  let end = offset + length;

  // 向左扩展到单词起始
  while (start > 0 && isWordChar(textContent[start - 1])) {
    start--;
  }

  // 向右扩展到单词结束
  while (end < textContent.length && isWordChar(textContent[end])) {
    end++;
  }

  return { offset: start, length: end - start };
}

// 从当前选区提取信息
export function getSelectionInfo(): SelectionInfo | null {
  const selection = window.getSelection();
  if (!selection || selection.isCollapsed || !selection.rangeCount) return null;

  const text = selection.toString().trim();
  if (!text) return null;

  const range = selection.getRangeAt(0);
  const startNode = range.startContainer;
  const endNode = range.endContainer;

  // 忽略 GlossPin 自身的标注元素
  const startParent = startNode.parentElement;
  if (startParent?.closest('[data-glosspin]')) return null;

  // 跨元素选区：直接使用原始选区文本，不做补全
  if (startNode !== endNode || startNode.nodeType !== Node.TEXT_NODE) {
    // 尝试用 startContainer 定位
    const anchorNode = startNode.nodeType === Node.TEXT_NODE ? startNode : startNode.firstChild;
    if (!anchorNode || anchorNode.nodeType !== Node.TEXT_NODE) return null;

    return {
      text,
      xpath: getXPath(anchorNode),
      textOffset: range.startOffset,
      textLength: text.length,
      range: range.cloneRange(),
    };
  }

  // 单文本节点内的选区：自动补全到完整单词
  const textContent = startNode.textContent || '';
  const isSingleWord = !/\s/.test(text);

  if (isSingleWord) {
    const expanded = expandToWord(textContent, range.startOffset, text.length);
    const expandedText = textContent.slice(expanded.offset, expanded.offset + expanded.length).trim();
    const finalText = expandedText || text;

    const expandedRange = document.createRange();
    expandedRange.setStart(startNode, expanded.offset);
    expandedRange.setEnd(startNode, expanded.offset + expanded.length);

    return {
      text: finalText,
      xpath: getXPath(startNode),
      textOffset: expanded.offset,
      textLength: expanded.length,
      range: expandedRange,
    };
  }

  // 多词短语：保持原始选区
  return {
    text,
    xpath: getXPath(startNode),
    textOffset: range.startOffset,
    textLength: text.length,
    range: range.cloneRange(),
  };
}
