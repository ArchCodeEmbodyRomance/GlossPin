// GlossPin Content Script 入口
// 划词 → 翻译请求 → 插入标注 → 持久化

import './styles.css';
import { getSelectionInfo } from './selection';
import { insertAnnotation, annotateAllOccurrences, restoreAnnotation, clearAllAnnotations } from './annotator';
import type { Annotation, Settings, TranslateResult } from '@/shared/types';
import type { MessageResponse } from '@/shared/messages';
import { nanoid } from 'nanoid';

// 当前页面的标注列表
let annotations: Annotation[] = [];

// 页面加载时恢复标注
async function restorePageAnnotations() {
  const url = location.href;
  console.log('[GlossPin] 恢复标注, URL:', url);
  const response: MessageResponse = await chrome.runtime.sendMessage({
    type: 'LOAD_ANNOTATIONS',
    url,
  });
  console.log('[GlossPin] 加载结果:', response);
  if (!response.success || !response.data) return;

  const saved = response.data as Annotation[];
  console.log('[GlossPin] 找到', saved.length, '条标注');
  // 从后往前恢复，避免前面插入后偏移量错乱
  for (let i = saved.length - 1; i >= 0; i--) {
    const ok = restoreAnnotation(saved[i]);
    console.log('[GlossPin] 恢复标注', saved[i].originalText, ok ? '成功' : '失败');
    if (ok) {
      annotations.unshift(saved[i]);
    }
  }
}

// 保存标注到 storage
async function saveAnnotations() {
  console.log('[GlossPin] 保存标注:', annotations.length, '条, URL:', location.href);
  await chrome.runtime.sendMessage({
    type: 'SAVE_ANNOTATIONS',
    url: location.href,
    annotations,
  });
}

// 获取设置
async function getSettings(): Promise<Settings> {
  const response: MessageResponse = await chrome.runtime.sendMessage({ type: 'GET_SETTINGS' });
  return response.data as Settings;
}

// 语言检测：根据字符特征判断文本所属语言
function detectLang(text: string): string | null {
  const clean = text.replace(/\s/g, '');
  if (!clean) return null;

  // 中文
  const zh = clean.match(/[\u4e00-\u9fff\u3400-\u4dbf]/g);
  if (zh && zh.length / clean.length > 0.5) return 'zh-CN';

  // 日语（平假名/片假名）
  const ja = clean.match(/[\u3040-\u309f\u30a0-\u30ff]/g);
  if (ja && ja.length / clean.length > 0.3) return 'ja';

  // 韩语
  const ko = clean.match(/[\uac00-\ud7af\u1100-\u11ff]/g);
  if (ko && ko.length / clean.length > 0.3) return 'ko';

  // 拉丁字母为主（英语/法语/德语/西班牙语等）
  const latin = clean.match(/[a-zA-Z\u00C0-\u024F]/g);
  if (latin && latin.length / clean.length > 0.7) return 'latin';

  // 西里尔字母（俄语等）
  const cyrillic = clean.match(/[\u0400-\u04ff]/g);
  if (cyrillic && cyrillic.length / clean.length > 0.5) return 'ru';

  // 阿拉伯语
  const arabic = clean.match(/[\u0600-\u06ff]/g);
  if (arabic && arabic.length / clean.length > 0.5) return 'ar';

  return null;
}

// 判断文本是否属于跳过翻译的语言
function shouldSkipTranslation(text: string, settings: Settings): boolean {
  const detected = detectLang(text);
  if (!detected) return false;

  // 目标语言本身不翻译
  if (detected === settings.targetLang) return true;

  // 用户配置的跳过语言
  const skipLangs = settings.skipLangs ?? [];
  return skipLangs.includes(detected);
}

// 翻译单个文本并创建标注
async function translateAndAnnotate(
  text: string,
  xpath: string,
  textOffset: number,
  textLength: number,
  range: Range,
): Promise<boolean> {
  const response: MessageResponse = await chrome.runtime.sendMessage({
    type: 'TRANSLATE',
    text,
    targetLang: 'zh-CN',
  });

  if (!response.success || !response.data) return false;
  const result = response.data as TranslateResult;

  const annotation: Annotation = {
    id: nanoid(),
    originalText: text,
    translation: result.translation,
    partOfSpeech: result.partOfSpeech,
    engine: result.engine,
    xpath,
    textOffset,
    textLength,
    createdAt: Date.now(),
    pinned: false,
  };

  if (annotateAllOccurrences(annotation) > 0) {
    annotations.push(annotation);
    return true;
  }
  return false;
}

// 判断文本是否包含多个单词
function isPhrase(text: string): boolean {
  return text.trim().split(/\s+/).length > 1;
}

// 划词翻译
async function handleSelection() {
  const info = getSelectionInfo();
  if (!info) return;

  const settings = await getSettings();

  // 跳过目标语言或指定不翻译的语言
  if (shouldSkipTranslation(info.text, settings)) return;

  // 多词短语 + 逐词模式：拆分为单词逐个翻译
  if (isPhrase(info.text) && settings.phraseMode === 'word-by-word') {
    const words = info.text.split(/\s+/);
    // 从后往前翻译，避免前面插入标注后偏移量错乱
    const textContent = info.range.startContainer.textContent || '';
    const startContainer = info.range.startContainer;
    const positions: { word: string; offset: number }[] = [];
    let searchFrom = info.textOffset;

    for (const word of words) {
      const idx = textContent.indexOf(word, searchFrom);
      if (idx === -1) continue;
      positions.push({ word, offset: idx });
      searchFrom = idx + word.length;
    }

    // 从后往前插入，这样前面的偏移量不受影响
    for (let i = positions.length - 1; i >= 0; i--) {
      const { word, offset } = positions[i];
      const wordRange = document.createRange();
      wordRange.setStart(startContainer, offset);
      wordRange.setEnd(startContainer, offset + word.length);
      await translateAndAnnotate(word, info.xpath, offset, word.length, wordRange);
    }
    await saveAnnotations();
    return;
  }

  // 单词或整句翻译
  const changed = await translateAndAnnotate(
    info.text, info.xpath, info.textOffset, info.textLength, info.range,
  );
  if (changed) await saveAnnotations();
}

// 监听划词（mouseup 事件）
document.addEventListener('mouseup', () => {
  // 延迟一帧，等待浏览器更新选区
  requestAnimationFrame(() => {
    handleSelection();
  });
});

// 清除当前页存储
async function clearPageStorage() {
  await chrome.runtime.sendMessage({
    type: 'CLEAR_ANNOTATIONS',
    url: location.href,
  });
}

// 监听标注删除事件
document.addEventListener('glosspin:remove', async (e) => {
  const id = (e as CustomEvent).detail;
  annotations = annotations.filter((a) => a.id !== id);
  if (annotations.length === 0) {
    await clearPageStorage();
  } else {
    await saveAnnotations();
  }
});

// 监听来自 Popup 的消息
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'CLEAR_PAGE_ANNOTATIONS') {
    clearAllAnnotations();
    annotations = [];
    clearPageStorage();
    sendResponse({ success: true });
  }
  return true;
});

// 页面加载完成后恢复
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => restorePageAnnotations());
} else {
  restorePageAnnotations();
}
