// 标注数据（按 URL 存储）
export interface Annotation {
  id: string;              // 唯一 ID（nanoid）
  originalText: string;    // 原文
  translation: string;     // 译文
  partOfSpeech?: string;   // 词性
  engine: string;          // 翻译引擎标识
  // 定位信息（用于页面恢复标注）
  xpath: string;           // 原文所在 DOM 节点的 XPath
  textOffset: number;      // 在文本节点中的偏移量
  textLength: number;      // 选中文本长度
  contextSelector?: string; // 最近有 id/class 的祖先元素选择器，用于精确恢复
  // 元数据
  createdAt: number;       // 时间戳
  pinned: boolean;         // 是否已收藏到生词本
}

// 生词本条目
export interface WordEntry {
  id: string;
  word: string;            // 原文
  translation: string;     // 译文
  context: string;         // 来源句子
  sourceUrl: string;       // 来源页面 URL
  sourceTitle: string;     // 来源页面标题
  engine: string;          // 翻译引擎
  createdAt: number;
  tags: string[];          // 用户标签（预留）
}

// 设置
export interface Settings {
  // 翻译
  targetLang: string;              // 目标语言，默认 'zh-CN'
  enginePriority: string[];        // 引擎优先级
  engineConfigs: Record<string, EngineConfig>;
  // 标注样式
  annotationStyle: AnnotationStyle;
  // 行为
  triggerMode: 'auto' | 'shortcut';
  phraseMode: 'whole' | 'word-by-word';  // 多词短语：整句翻译 / 逐词翻译
  shortcuts: Record<string, string>;
  // 站点规则
  siteMode: 'blacklist' | 'whitelist';
  siteList: string[];
  // 跳过翻译的语言列表
  skipLangs: string[];
}

export interface EngineConfig {
  enabled: boolean;
  apiKey?: string;
  endpoint?: string;
}

export interface AnnotationStyle {
  color: string;
  fontSize: 'small' | 'medium' | 'large';
  format: 'bracket' | 'subscript' | 'superscript';
}

// 翻译结果
export interface TranslateResult {
  translation: string;
  engine: string;
  partOfSpeech?: string;   // 词性（如 n. adj. v.）
  phonetic?: string;       // 音标
  definitions?: string[];  // 详细释义
  examples?: string[];     // 例句
}
