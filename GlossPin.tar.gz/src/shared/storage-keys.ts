// chrome.storage.local 存储 key 前缀和常量

// 标注数据：annotations:{url} → Annotation[]
export const ANNOTATIONS_PREFIX = 'annotations:';

// 生词本：wordbook → WordEntry[]
export const WORDBOOK_KEY = 'wordbook';

// 设置：settings → Settings
export const SETTINGS_KEY = 'settings';

// 扩展启用状态：enabled → boolean
export const ENABLED_KEY = 'enabled';

export function annotationsKey(url: string): string {
  return `${ANNOTATIONS_PREFIX}${url}`;
}
