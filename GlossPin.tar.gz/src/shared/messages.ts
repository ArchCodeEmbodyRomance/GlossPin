import type { Annotation, Settings, TranslateResult, WordEntry } from './types';

// Content Script → Background 请求
export type Message =
  | TranslateRequest
  | SaveAnnotationsRequest
  | LoadAnnotationsRequest
  | PinWordRequest
  | GetSettingsRequest
  | UpdateSettingsRequest
  | ClearAnnotationsRequest
  | ClearAllAnnotationsRequest
  | GetStorageStatsRequest;

// 翻译请求
export interface TranslateRequest {
  type: 'TRANSLATE';
  text: string;
  targetLang: string;
  engine?: string;
}

// 标注持久化
export interface SaveAnnotationsRequest {
  type: 'SAVE_ANNOTATIONS';
  url: string;
  annotations: Annotation[];
}

export interface LoadAnnotationsRequest {
  type: 'LOAD_ANNOTATIONS';
  url: string;
}

export interface ClearAnnotationsRequest {
  type: 'CLEAR_ANNOTATIONS';
  url: string;
}

export interface ClearAllAnnotationsRequest {
  type: 'CLEAR_ALL_ANNOTATIONS';
}

export interface GetStorageStatsRequest {
  type: 'GET_STORAGE_STATS';
}

// 生词本
export interface PinWordRequest {
  type: 'PIN_WORD';
  entry: WordEntry;
}

// 设置
export interface GetSettingsRequest {
  type: 'GET_SETTINGS';
}

export interface UpdateSettingsRequest {
  type: 'UPDATE_SETTINGS';
  settings: Partial<Settings>;
}

// 响应类型
export type MessageResponse =
  | { success: true; data?: unknown }
  | { success: false; error: string };
