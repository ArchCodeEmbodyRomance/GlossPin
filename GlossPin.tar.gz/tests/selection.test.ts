import { describe, it, expect, beforeEach } from 'vitest';
import { getXPath, getSelectionInfo } from '@/content/selection';

describe('selection', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
  });

  describe('getXPath', () => {
    it('为文本节点生成正确的 XPath', () => {
      document.body.innerHTML = '<p>Hello World</p>';
      const textNode = document.querySelector('p')!.firstChild!;
      const xpath = getXPath(textNode);
      expect(xpath).toContain('p');
      expect(xpath).toContain('text()');
    });

    it('为嵌套元素生成正确的 XPath', () => {
      document.body.innerHTML = '<div><p><span>Test</span></p></div>';
      const textNode = document.querySelector('span')!.firstChild!;
      const xpath = getXPath(textNode);
      expect(xpath).toContain('div');
      expect(xpath).toContain('span');
      expect(xpath).toContain('text()');
    });
  });

  describe('getSelectionInfo', () => {
    it('无选区时返回 null', () => {
      expect(getSelectionInfo()).toBeNull();
    });

    it('选区为空时返回 null', () => {
      window.getSelection()?.removeAllRanges();
      expect(getSelectionInfo()).toBeNull();
    });
  });
});
