import { describe, it, expect } from 'vitest';
import { annotationsKey } from '@/shared/storage-keys';

describe('storage-keys', () => {
  it('生成正确的标注存储 key', () => {
    const url = 'https://example.com/page';
    expect(annotationsKey(url)).toBe('annotations:https://example.com/page');
  });
});
