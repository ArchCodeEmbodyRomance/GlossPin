import { describe, it, expect, vi, beforeEach } from 'vitest';
import { translate, registerEngine } from '@/background/translator';
import type { TranslateEngine } from '@/background/engines/types';
import type { TranslateResult } from '@/shared/types';

// mock 引擎
function createMockEngine(name: string, result?: string, shouldFail = false): TranslateEngine {
  return {
    name,
    translate: vi.fn(async (): Promise<TranslateResult> => {
      if (shouldFail) throw new Error(`${name} 失败`);
      return { translation: result ?? `${name}-翻译`, engine: name };
    }),
    test: vi.fn(async () => !shouldFail),
  };
}

describe('translator', () => {
  beforeEach(() => {
    // 注册测试引擎
    registerEngine(createMockEngine('engineA', '引擎A结果'));
    registerEngine(createMockEngine('engineB', '引擎B结果'));
  });

  it('按指定引擎翻译', async () => {
    const result = await translate('hello', 'zh-CN', ['engineA'], 'engineB');
    expect(result.translation).toBe('引擎B结果');
    expect(result.engine).toBe('engineB');
  });

  it('按优先级顺序翻译', async () => {
    const result = await translate('hello', 'zh-CN', ['engineA', 'engineB']);
    expect(result.translation).toBe('引擎A结果');
    expect(result.engine).toBe('engineA');
  });

  it('引擎失败时 fallback 到下一个', async () => {
    registerEngine(createMockEngine('engineA', '', true));
    const result = await translate('hello', 'zh-CN', ['engineA', 'engineB']);
    expect(result.translation).toBe('引擎B结果');
    expect(result.engine).toBe('engineB');
  });

  it('所有引擎失败时抛出错误', async () => {
    registerEngine(createMockEngine('engineA', '', true));
    registerEngine(createMockEngine('engineB', '', true));
    await expect(
      translate('hello', 'zh-CN', ['engineA', 'engineB']),
    ).rejects.toThrow('所有翻译引擎均失败');
  });
});
